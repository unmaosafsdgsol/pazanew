<<<<<<< HEAD
print ("wellcome to mte world")
print ("뭉탱이월드에 오신걸 환영합니다.")
=======
print("wellcome to mte world")
print("사각형의 넓이 구하기")

def calc_area(x,y):
    result =x*y
    return result
>>>>>>> feature/calc_area
