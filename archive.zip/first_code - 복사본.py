<<<<<<< HEAD
print ("wellcome to mte world")
print ("사각형의 넓이 구하기")


def calc_area(x,y):
    result =x*y
    return result
=======
print("hello world")
print("1부터 10까지 더하세요")
total = 0

for i in range(1, 11):
    total += i

print("1부터 10까지의 합:", total)
>>>>>>> feature/calc_area
