print("hello world")
print("1부터 10까지 더하세요")
total = 0

for i in range(1, 11):
    total += i

print("1부터 10까지의 합:", total)
